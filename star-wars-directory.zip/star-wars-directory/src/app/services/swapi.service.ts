import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, map, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class SwapiService {
  constructor(private http: HttpClient) {}

  async getAllPeople(): Promise<any[]> {
    const urls = Array.from({ length: 9 }, (_, i) => `https://swapi.py4e.com/api/people/?page=${i + 1}`);

    const responses = await Promise.all(urls.map(url => this.http.get<any>(url).toPromise()));
    const rawCharacters = responses.flatMap(r => r.results);

    const enriched = await Promise.all(rawCharacters.map(char => this.enrichCharacter(char)));
    return enriched;
  }

  enrichCharacter(character: any): Promise<any> {
    const filmTitles$ = this.getNames(character.films).toPromise();
    const speciesNames$ = this.getNames(character.species).toPromise();

    return Promise.all([filmTitles$, speciesNames$]).then(([filmTitles, speciesNames]) => ({
      ...character,
      filmTitles,
      speciesNames
    }));
  }

  getPerson(id: number) {
    return this.http.get<any>(`https://swapi.py4e.com/api/people/${id}/`);
  }

  getNames(urls: string[]) {
    return urls.length ? forkJoin(urls.map(url => this.getName(url))) : of([]);
  }

  getName(url: string) {
    return url
      ? this.http.get<any>(url).pipe(map(res => res.name || res.title))
      : of('Unknown');
  }
}
