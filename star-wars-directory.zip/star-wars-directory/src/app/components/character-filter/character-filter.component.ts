import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-character-filter',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './character-filter.component.html'
})
export class CharacterFilterComponent {
  @Output() filterChange = new EventEmitter<any>();
  filter: any = {};

  movies: string[] = [
    'A New Hope',
    'The Empire Strikes Back',
    'Return of the Jedi',
    'Revenge of the Sith',
    'The Force Awakens'
  ];

  species: string[] = ['Human', 'Droid', 'Wookiee', 'Rodian', 'Hutt'];

  handleSelectChange(event: Event, key: string) {
    const value = (event.target as HTMLSelectElement).value;
    this.emitFilter(value, key);
  }

  emitFilter(value: string, key: string) {
    console.log('Filter selected:', key, value);
    this.filter[key] = value;
    this.filterChange.emit(this.filter);
  }


  toNumber = (val: string | null): number => {
    return Number(val);
  };
  handleRangeInput(event: Event, key: string) {
    const value = (event.target as HTMLInputElement).value;
    this.emitFilter(value, key);
  }
  handleBirthYearInput(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.emitFilter(value, 'birth_year');
  }


}
