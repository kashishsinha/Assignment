import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { SwapiService } from '../../services/swapi.service';
import { CharacterFilterComponent } from '../character-filter/character-filter.component';

@Component({
  selector: 'app-character-list',
  standalone: true,
  imports: [CommonModule, RouterLink, CharacterFilterComponent],
  templateUrl: './character-list.component.html'
})
export class CharacterListComponent implements OnInit {
  characters: any[] = [];
  filteredCharacters: any[] = [];
  itemsPerPage = 5;
  currentPage = 1;
  isLoading = true;

  constructor(private swapi: SwapiService) { }
  ngOnInit(): void {
    this.isLoading = true;
    this.swapi.getAllPeople().then(characters => {
      this.characters = characters;
      this.filteredCharacters = [...characters];
      this.isLoading = false;
    });
  }

  onFilterChange(filter: any) {
    const movieFilter = typeof filter.movie === 'string' ? filter.movie.trim().toLowerCase() : '';
    const speciesFilter = typeof filter.species === 'string' ? filter.species.trim().toLowerCase() : '';
    const vehicleFilter = typeof filter.vehicle === 'string' ? filter.vehicle.trim().toLowerCase() : '';
    const starshipFilter = typeof filter.starship === 'string' ? filter.starship.trim().toLowerCase() : '';

    this.filteredCharacters = this.characters.filter(char => {
      const matchesMovie = !movieFilter || (char.filmTitles || []).some((title: string) =>
        title?.toLowerCase().trim() === movieFilter);

      const matchesSpecies = !speciesFilter || (char.speciesNames || []).some((sp: string) =>
        sp?.toLowerCase().trim() === speciesFilter);


      const matchesVehicle = !vehicleFilter || (char.vehicles || []).some((v: string) =>
        v?.toLowerCase().includes(vehicleFilter));

      const matchesStarship = !starshipFilter || (char.starships || []).some((s: string) =>
        s?.toLowerCase().includes(starshipFilter));

      const matchesBirthYear = !filter.birth_year ||
        (char.birth_year?.toLowerCase().includes(filter.birth_year.toLowerCase().trim()));


      return matchesMovie && matchesSpecies && matchesVehicle && matchesStarship && matchesBirthYear;
    });

    this.currentPage = 1;
    console.log("Filter works");
  }

  inRange(birthYear: string, from?: string, to?: string): boolean {
    if (!birthYear) return true;

    // If no from or to provided, allow all
    if (!from && !to) return true;

    const cleanYear = birthYear.toLowerCase().trim();

    // String comparison (e.g., contains, startsWith)
    if (from && !cleanYear.includes(from.toLowerCase().trim())) return false;
    if (to && !cleanYear.includes(to.toLowerCase().trim())) return false;

    return true;
  }



  getId(url: string): number {
    return parseInt(url.split('/').filter(Boolean).pop() || '', 10);
  }

  paginatedCharacters() {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredCharacters.slice(start, start + this.itemsPerPage);
  }

  totalPagesArray(): number[] {
    const totalPages = Math.ceil(this.filteredCharacters.length / this.itemsPerPage);
    const maxVisible = 3;

    let start = Math.max(this.currentPage - Math.floor(maxVisible / 2), 1);
    let end = start + maxVisible - 1;

    if (end > totalPages) {
      end = totalPages;
      start = Math.max(end - maxVisible + 1, 1);
    }

    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }
  visiblePages(): number[] {
    const total = this.totalPagesArray();
    const current = this.currentPage;

    return total.filter(p => Math.abs(p - current) <= 2);
  }
  goToPreviousPage(): void {
    this.currentPage = Math.max(this.currentPage - 1, 1);
  }

  goToNextPage(): void {
    const total = this.totalPagesArray().length;
    this.currentPage = Math.min(this.currentPage + 1, total);
  }

}
