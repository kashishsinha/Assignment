import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SwapiService } from '../../services/swapi.service';

@Component({
  selector: 'app-character-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './character-detail.component.html'  
})
export class CharacterDetailComponent implements OnInit {
  character: any;
 // species: string = '';
  films: string[] = [];
  starships: string[] = [];
movies: string[] = [
  'A New Hope', 'The Empire Strikes Back', 'Return of the Jedi',
  'The Phantom Menace', 'Attack of the Clones', 'Revenge of the Sith',
  'The Force Awakens'
];

species: string[] = [
  'Human', 'Droid', 'Wookiee', 'Rodian', 'Hutt', "Yoda's species", 'Trandoshan'
];

  constructor(private route: ActivatedRoute, private swapi: SwapiService) {}

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.swapi.getPerson(id).subscribe(char => {
      this.character = char;
      this.loadDetails(char);
    });
  }

  loadDetails(char: any) {
    this.swapi.getName(char.species[0]).subscribe(s => this.species = s);
    this.swapi.getNames(char.films).subscribe(f => this.films = f);
    this.swapi.getNames(char.starships).subscribe(s => this.starships = s);
  }
}